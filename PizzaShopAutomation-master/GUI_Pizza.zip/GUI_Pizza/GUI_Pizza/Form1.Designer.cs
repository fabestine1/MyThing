﻿namespace GUI_Pizza
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.lblWelcome = new System.Windows.Forms.Label();
            this.btnLogin = new System.Windows.Forms.Button();
            this.pnlPage2 = new System.Windows.Forms.Panel();
            this.lblPizza2Count = new System.Windows.Forms.Label();
            this.lblPizza1Count = new System.Windows.Forms.Label();
            this.pnlPage3 = new System.Windows.Forms.Panel();
            this.btnServe = new System.Windows.Forms.Button();
            this.lbxReadyOrders = new System.Windows.Forms.ListBox();
            this.btnReadyOrders2 = new System.Windows.Forms.Button();
            this.btnNewOrder2 = new System.Windows.Forms.Button();
            this.lblOrders = new System.Windows.Forms.Label();
            this.lblCashier2 = new System.Windows.Forms.Label();
            this.ReadyOrders = new System.Windows.Forms.Button();
            this.btnNewOrder = new System.Windows.Forms.Button();
            this.btnConfirmOrder = new System.Windows.Forms.Button();
            this.btnPizza2Remove = new System.Windows.Forms.Button();
            this.btnPizza2Add = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.lblPizza3Count = new System.Windows.Forms.Label();
            this.btnPizza3Add = new System.Windows.Forms.Button();
            this.btnPizza1Remove = new System.Windows.Forms.Button();
            this.btnPizza1Add = new System.Windows.Forms.Button();
            this.clbPizza3 = new System.Windows.Forms.CheckedListBox();
            this.clbPizza2 = new System.Windows.Forms.CheckedListBox();
            this.clbPizza1 = new System.Windows.Forms.CheckedListBox();
            this.lblStatus = new System.Windows.Forms.Label();
            this.lblOrder = new System.Windows.Forms.Label();
            this.lblCashier = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.tbxLogin = new System.Windows.Forms.TextBox();
            this.tmrTick = new System.Windows.Forms.Timer(this.components);
            this.pnlLogo3 = new System.Windows.Forms.Panel();
            this.pnlPizza2 = new System.Windows.Forms.Panel();
            this.pnlPizza3 = new System.Windows.Forms.Panel();
            this.pnlPizza1 = new System.Windows.Forms.Panel();
            this.pnlLogo2 = new System.Windows.Forms.Panel();
            this.pnlLogo = new System.Windows.Forms.Panel();
            this.pnlPage2.SuspendLayout();
            this.pnlPage3.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblWelcome
            // 
            this.lblWelcome.AutoSize = true;
            this.lblWelcome.Font = new System.Drawing.Font("Arial Rounded MT Bold", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblWelcome.ForeColor = System.Drawing.Color.OliveDrab;
            this.lblWelcome.Location = new System.Drawing.Point(23, 9);
            this.lblWelcome.Name = "lblWelcome";
            this.lblWelcome.Size = new System.Drawing.Size(318, 140);
            this.lblWelcome.TabIndex = 0;
            this.lblWelcome.Text = "Welcome,\r\nMario";
            this.lblWelcome.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btnLogin
            // 
            this.btnLogin.BackColor = System.Drawing.Color.OliveDrab;
            this.btnLogin.Font = new System.Drawing.Font("Arial Rounded MT Bold", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLogin.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnLogin.Location = new System.Drawing.Point(12, 467);
            this.btnLogin.Name = "btnLogin";
            this.btnLogin.Size = new System.Drawing.Size(329, 95);
            this.btnLogin.TabIndex = 2;
            this.btnLogin.Text = "Log in";
            this.btnLogin.UseVisualStyleBackColor = false;
            this.btnLogin.Click += new System.EventHandler(this.BtnLogin_Click);
            // 
            // pnlPage2
            // 
            this.pnlPage2.Controls.Add(this.pnlPage3);
            this.pnlPage2.Controls.Add(this.lblPizza2Count);
            this.pnlPage2.Controls.Add(this.lblPizza1Count);
            this.pnlPage2.Controls.Add(this.ReadyOrders);
            this.pnlPage2.Controls.Add(this.btnNewOrder);
            this.pnlPage2.Controls.Add(this.btnConfirmOrder);
            this.pnlPage2.Controls.Add(this.btnPizza2Remove);
            this.pnlPage2.Controls.Add(this.btnPizza2Add);
            this.pnlPage2.Controls.Add(this.button3);
            this.pnlPage2.Controls.Add(this.lblPizza3Count);
            this.pnlPage2.Controls.Add(this.btnPizza3Add);
            this.pnlPage2.Controls.Add(this.btnPizza1Remove);
            this.pnlPage2.Controls.Add(this.btnPizza1Add);
            this.pnlPage2.Controls.Add(this.clbPizza3);
            this.pnlPage2.Controls.Add(this.clbPizza2);
            this.pnlPage2.Controls.Add(this.clbPizza1);
            this.pnlPage2.Controls.Add(this.pnlPizza2);
            this.pnlPage2.Controls.Add(this.pnlPizza3);
            this.pnlPage2.Controls.Add(this.pnlPizza1);
            this.pnlPage2.Controls.Add(this.pnlLogo2);
            this.pnlPage2.Controls.Add(this.lblStatus);
            this.pnlPage2.Controls.Add(this.lblOrder);
            this.pnlPage2.Controls.Add(this.lblCashier);
            this.pnlPage2.Controls.Add(this.panel1);
            this.pnlPage2.Controls.Add(this.panel3);
            this.pnlPage2.Controls.Add(this.panel2);
            this.pnlPage2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlPage2.Location = new System.Drawing.Point(0, 0);
            this.pnlPage2.Name = "pnlPage2";
            this.pnlPage2.Size = new System.Drawing.Size(363, 574);
            this.pnlPage2.TabIndex = 3;
            this.pnlPage2.Visible = false;
            // 
            // lblPizza2Count
            // 
            this.lblPizza2Count.AutoSize = true;
            this.lblPizza2Count.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.lblPizza2Count.Font = new System.Drawing.Font("Arial Rounded MT Bold", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPizza2Count.ForeColor = System.Drawing.Color.White;
            this.lblPizza2Count.Location = new System.Drawing.Point(265, 275);
            this.lblPizza2Count.Name = "lblPizza2Count";
            this.lblPizza2Count.Size = new System.Drawing.Size(33, 34);
            this.lblPizza2Count.TabIndex = 27;
            this.lblPizza2Count.Text = "0";
            // 
            // lblPizza1Count
            // 
            this.lblPizza1Count.AutoSize = true;
            this.lblPizza1Count.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.lblPizza1Count.Font = new System.Drawing.Font("Arial Rounded MT Bold", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPizza1Count.ForeColor = System.Drawing.Color.White;
            this.lblPizza1Count.Location = new System.Drawing.Point(265, 173);
            this.lblPizza1Count.Name = "lblPizza1Count";
            this.lblPizza1Count.Size = new System.Drawing.Size(33, 34);
            this.lblPizza1Count.TabIndex = 26;
            this.lblPizza1Count.Text = "0";
            // 
            // pnlPage3
            // 
            this.pnlPage3.Controls.Add(this.btnServe);
            this.pnlPage3.Controls.Add(this.lbxReadyOrders);
            this.pnlPage3.Controls.Add(this.btnReadyOrders2);
            this.pnlPage3.Controls.Add(this.btnNewOrder2);
            this.pnlPage3.Controls.Add(this.lblOrders);
            this.pnlPage3.Controls.Add(this.pnlLogo3);
            this.pnlPage3.Controls.Add(this.lblCashier2);
            this.pnlPage3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlPage3.Location = new System.Drawing.Point(0, 0);
            this.pnlPage3.Name = "pnlPage3";
            this.pnlPage3.Size = new System.Drawing.Size(363, 574);
            this.pnlPage3.TabIndex = 25;
            this.pnlPage3.Visible = false;
            // 
            // btnServe
            // 
            this.btnServe.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnServe.Location = new System.Drawing.Point(0, 488);
            this.btnServe.Name = "btnServe";
            this.btnServe.Size = new System.Drawing.Size(363, 37);
            this.btnServe.TabIndex = 28;
            this.btnServe.Text = "Served!";
            this.btnServe.UseVisualStyleBackColor = true;
            this.btnServe.Click += new System.EventHandler(this.BtnServe_Click);
            // 
            // lbxReadyOrders
            // 
            this.lbxReadyOrders.Font = new System.Drawing.Font("Arial Rounded MT Bold", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbxReadyOrders.FormattingEnabled = true;
            this.lbxReadyOrders.HorizontalScrollbar = true;
            this.lbxReadyOrders.ItemHeight = 20;
            this.lbxReadyOrders.Location = new System.Drawing.Point(21, 142);
            this.lbxReadyOrders.Name = "lbxReadyOrders";
            this.lbxReadyOrders.Size = new System.Drawing.Size(320, 324);
            this.lbxReadyOrders.TabIndex = 27;
            // 
            // btnReadyOrders2
            // 
            this.btnReadyOrders2.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnReadyOrders2.Location = new System.Drawing.Point(183, 532);
            this.btnReadyOrders2.Name = "btnReadyOrders2";
            this.btnReadyOrders2.Size = new System.Drawing.Size(180, 42);
            this.btnReadyOrders2.TabIndex = 26;
            this.btnReadyOrders2.Text = "Ready orders";
            this.btnReadyOrders2.UseVisualStyleBackColor = true;
            this.btnReadyOrders2.Click += new System.EventHandler(this.BtnReadyOrders2_Click);
            // 
            // btnNewOrder2
            // 
            this.btnNewOrder2.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNewOrder2.Location = new System.Drawing.Point(0, 532);
            this.btnNewOrder2.Name = "btnNewOrder2";
            this.btnNewOrder2.Size = new System.Drawing.Size(177, 42);
            this.btnNewOrder2.TabIndex = 25;
            this.btnNewOrder2.Text = "New order";
            this.btnNewOrder2.UseVisualStyleBackColor = true;
            this.btnNewOrder2.Click += new System.EventHandler(this.BtnNewOrder2_Click);
            // 
            // lblOrders
            // 
            this.lblOrders.AutoSize = true;
            this.lblOrders.Font = new System.Drawing.Font("Arial Rounded MT Bold", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblOrders.Location = new System.Drawing.Point(7, 87);
            this.lblOrders.Name = "lblOrders";
            this.lblOrders.Size = new System.Drawing.Size(159, 46);
            this.lblOrders.TabIndex = 6;
            this.lblOrders.Text = "Orders";
            // 
            // lblCashier2
            // 
            this.lblCashier2.AutoSize = true;
            this.lblCashier2.BackColor = System.Drawing.Color.DarkOrange;
            this.lblCashier2.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCashier2.Location = new System.Drawing.Point(2, 4);
            this.lblCashier2.Name = "lblCashier2";
            this.lblCashier2.Size = new System.Drawing.Size(152, 23);
            this.lblCashier2.TabIndex = 1;
            this.lblCashier2.Text = "Cashier: Mario";
            // 
            // ReadyOrders
            // 
            this.ReadyOrders.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ReadyOrders.Location = new System.Drawing.Point(183, 532);
            this.ReadyOrders.Name = "ReadyOrders";
            this.ReadyOrders.Size = new System.Drawing.Size(180, 42);
            this.ReadyOrders.TabIndex = 24;
            this.ReadyOrders.Text = "Ready orders";
            this.ReadyOrders.UseVisualStyleBackColor = true;
            this.ReadyOrders.Click += new System.EventHandler(this.ReadyOrders_Click);
            // 
            // btnNewOrder
            // 
            this.btnNewOrder.Enabled = false;
            this.btnNewOrder.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNewOrder.Location = new System.Drawing.Point(0, 532);
            this.btnNewOrder.Name = "btnNewOrder";
            this.btnNewOrder.Size = new System.Drawing.Size(177, 42);
            this.btnNewOrder.TabIndex = 23;
            this.btnNewOrder.Text = "New order";
            this.btnNewOrder.UseVisualStyleBackColor = true;
            this.btnNewOrder.Click += new System.EventHandler(this.BtnNewOrder_Click);
            // 
            // btnConfirmOrder
            // 
            this.btnConfirmOrder.BackColor = System.Drawing.Color.LimeGreen;
            this.btnConfirmOrder.Font = new System.Drawing.Font("Arial Rounded MT Bold", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnConfirmOrder.Location = new System.Drawing.Point(53, 467);
            this.btnConfirmOrder.Name = "btnConfirmOrder";
            this.btnConfirmOrder.Size = new System.Drawing.Size(253, 58);
            this.btnConfirmOrder.TabIndex = 22;
            this.btnConfirmOrder.Text = "Confirm order";
            this.btnConfirmOrder.UseVisualStyleBackColor = false;
            this.btnConfirmOrder.Click += new System.EventHandler(this.BtnConfirmOrder_Click);
            // 
            // btnPizza2Remove
            // 
            this.btnPizza2Remove.BackColor = System.Drawing.SystemColors.GrayText;
            this.btnPizza2Remove.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPizza2Remove.ForeColor = System.Drawing.Color.White;
            this.btnPizza2Remove.Location = new System.Drawing.Point(316, 274);
            this.btnPizza2Remove.Name = "btnPizza2Remove";
            this.btnPizza2Remove.Size = new System.Drawing.Size(35, 35);
            this.btnPizza2Remove.TabIndex = 21;
            this.btnPizza2Remove.Text = "-";
            this.btnPizza2Remove.UseVisualStyleBackColor = false;
            this.btnPizza2Remove.Click += new System.EventHandler(this.BtnPizza2Remove_Click);
            // 
            // btnPizza2Add
            // 
            this.btnPizza2Add.BackColor = System.Drawing.SystemColors.GrayText;
            this.btnPizza2Add.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPizza2Add.ForeColor = System.Drawing.Color.White;
            this.btnPizza2Add.Location = new System.Drawing.Point(230, 274);
            this.btnPizza2Add.Name = "btnPizza2Add";
            this.btnPizza2Add.Size = new System.Drawing.Size(35, 35);
            this.btnPizza2Add.TabIndex = 19;
            this.btnPizza2Add.Text = "+";
            this.btnPizza2Add.UseVisualStyleBackColor = false;
            this.btnPizza2Add.Click += new System.EventHandler(this.BtnPizza2Add_Click);
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.SystemColors.GrayText;
            this.button3.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3.ForeColor = System.Drawing.Color.White;
            this.button3.Location = new System.Drawing.Point(316, 383);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(35, 35);
            this.button3.TabIndex = 18;
            this.button3.Text = "-";
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.Button3_Click);
            // 
            // lblPizza3Count
            // 
            this.lblPizza3Count.AutoSize = true;
            this.lblPizza3Count.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.lblPizza3Count.Font = new System.Drawing.Font("Arial Rounded MT Bold", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPizza3Count.ForeColor = System.Drawing.Color.White;
            this.lblPizza3Count.Location = new System.Drawing.Point(265, 384);
            this.lblPizza3Count.Name = "lblPizza3Count";
            this.lblPizza3Count.Size = new System.Drawing.Size(33, 34);
            this.lblPizza3Count.TabIndex = 17;
            this.lblPizza3Count.Text = "0";
            // 
            // btnPizza3Add
            // 
            this.btnPizza3Add.BackColor = System.Drawing.SystemColors.GrayText;
            this.btnPizza3Add.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPizza3Add.ForeColor = System.Drawing.Color.White;
            this.btnPizza3Add.Location = new System.Drawing.Point(230, 383);
            this.btnPizza3Add.Name = "btnPizza3Add";
            this.btnPizza3Add.Size = new System.Drawing.Size(35, 35);
            this.btnPizza3Add.TabIndex = 16;
            this.btnPizza3Add.Text = "+";
            this.btnPizza3Add.UseVisualStyleBackColor = false;
            this.btnPizza3Add.Click += new System.EventHandler(this.BtnPizza3Add_Click);
            // 
            // btnPizza1Remove
            // 
            this.btnPizza1Remove.BackColor = System.Drawing.SystemColors.GrayText;
            this.btnPizza1Remove.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPizza1Remove.ForeColor = System.Drawing.Color.White;
            this.btnPizza1Remove.Location = new System.Drawing.Point(316, 172);
            this.btnPizza1Remove.Name = "btnPizza1Remove";
            this.btnPizza1Remove.Size = new System.Drawing.Size(35, 35);
            this.btnPizza1Remove.TabIndex = 12;
            this.btnPizza1Remove.Text = "-";
            this.btnPizza1Remove.UseVisualStyleBackColor = false;
            this.btnPizza1Remove.Click += new System.EventHandler(this.BtnPizza1Remove_Click);
            // 
            // btnPizza1Add
            // 
            this.btnPizza1Add.BackColor = System.Drawing.SystemColors.GrayText;
            this.btnPizza1Add.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPizza1Add.ForeColor = System.Drawing.Color.White;
            this.btnPizza1Add.Location = new System.Drawing.Point(230, 172);
            this.btnPizza1Add.Name = "btnPizza1Add";
            this.btnPizza1Add.Size = new System.Drawing.Size(35, 35);
            this.btnPizza1Add.TabIndex = 10;
            this.btnPizza1Add.Text = "+";
            this.btnPizza1Add.UseVisualStyleBackColor = false;
            this.btnPizza1Add.Click += new System.EventHandler(this.BtnPizza1Add_Click);
            // 
            // clbPizza3
            // 
            this.clbPizza3.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.clbPizza3.FormattingEnabled = true;
            this.clbPizza3.Items.AddRange(new object[] {
            "Cheese",
            "Bacon",
            "Sausage",
            "Extra sauce",
            "Thick dough"});
            this.clbPizza3.Location = new System.Drawing.Point(115, 359);
            this.clbPizza3.Name = "clbPizza3";
            this.clbPizza3.Size = new System.Drawing.Size(126, 102);
            this.clbPizza3.TabIndex = 9;
            // 
            // clbPizza2
            // 
            this.clbPizza2.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.clbPizza2.FormattingEnabled = true;
            this.clbPizza2.Items.AddRange(new object[] {
            "Cheese",
            "Bacon",
            "Sausage",
            "Extra sauce",
            "Thick dough"});
            this.clbPizza2.Location = new System.Drawing.Point(115, 254);
            this.clbPizza2.Name = "clbPizza2";
            this.clbPizza2.Size = new System.Drawing.Size(126, 102);
            this.clbPizza2.TabIndex = 8;
            // 
            // clbPizza1
            // 
            this.clbPizza1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.clbPizza1.FormattingEnabled = true;
            this.clbPizza1.Items.AddRange(new object[] {
            "Cheese",
            "Bacon",
            "Sausage",
            "Extra sauce",
            "Thick dough"});
            this.clbPizza1.Location = new System.Drawing.Point(115, 148);
            this.clbPizza1.Name = "clbPizza1";
            this.clbPizza1.Size = new System.Drawing.Size(126, 102);
            this.clbPizza1.TabIndex = 7;
            // 
            // lblStatus
            // 
            this.lblStatus.AutoSize = true;
            this.lblStatus.BackColor = System.Drawing.Color.White;
            this.lblStatus.Font = new System.Drawing.Font("Arial Rounded MT Bold", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblStatus.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.lblStatus.Location = new System.Drawing.Point(3, 111);
            this.lblStatus.Name = "lblStatus";
            this.lblStatus.Size = new System.Drawing.Size(125, 17);
            this.lblStatus.TabIndex = 3;
            this.lblStatus.Text = "Status: Entering";
            this.lblStatus.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblOrder
            // 
            this.lblOrder.AutoSize = true;
            this.lblOrder.BackColor = System.Drawing.Color.White;
            this.lblOrder.Font = new System.Drawing.Font("Arial Rounded MT Bold", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblOrder.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.lblOrder.Location = new System.Drawing.Point(4, 91);
            this.lblOrder.Name = "lblOrder";
            this.lblOrder.Size = new System.Drawing.Size(114, 17);
            this.lblOrder.TabIndex = 2;
            this.lblOrder.Text = "Order: #34893";
            // 
            // lblCashier
            // 
            this.lblCashier.AutoSize = true;
            this.lblCashier.BackColor = System.Drawing.Color.DarkOrange;
            this.lblCashier.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCashier.Location = new System.Drawing.Point(4, 4);
            this.lblCashier.Name = "lblCashier";
            this.lblCashier.Size = new System.Drawing.Size(152, 23);
            this.lblCashier.TabIndex = 0;
            this.lblCashier.Text = "Cashier: Mario";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.panel1.Location = new System.Drawing.Point(262, 173);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(56, 34);
            this.panel1.TabIndex = 28;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.panel3.Location = new System.Drawing.Point(262, 275);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(56, 34);
            this.panel3.TabIndex = 29;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.panel2.Location = new System.Drawing.Point(262, 384);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(56, 34);
            this.panel2.TabIndex = 29;
            // 
            // tbxLogin
            // 
            this.tbxLogin.Font = new System.Drawing.Font("Arial Rounded MT Bold", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbxLogin.Location = new System.Drawing.Point(15, 409);
            this.tbxLogin.Name = "tbxLogin";
            this.tbxLogin.Size = new System.Drawing.Size(325, 39);
            this.tbxLogin.TabIndex = 4;
            this.tbxLogin.TextChanged += new System.EventHandler(this.TbxLogin_TextChanged);
            // 
            // tmrTick
            // 
            this.tmrTick.Tick += new System.EventHandler(this.TmrTick_Tick);
            // 
            // pnlLogo3
            // 
            this.pnlLogo3.BackgroundImage = global::GUI_Pizza.Properties.Resources.unknown;
            this.pnlLogo3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pnlLogo3.Location = new System.Drawing.Point(167, 3);
            this.pnlLogo3.Name = "pnlLogo3";
            this.pnlLogo3.Size = new System.Drawing.Size(188, 128);
            this.pnlLogo3.TabIndex = 5;
            // 
            // pnlPizza2
            // 
            this.pnlPizza2.BackgroundImage = global::GUI_Pizza.Properties.Resources._20130804_261736_bufalina_pizza_austin_tx_margherita;
            this.pnlPizza2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pnlPizza2.Location = new System.Drawing.Point(8, 246);
            this.pnlPizza2.Name = "pnlPizza2";
            this.pnlPizza2.Size = new System.Drawing.Size(100, 100);
            this.pnlPizza2.TabIndex = 6;
            // 
            // pnlPizza3
            // 
            this.pnlPizza3.BackgroundImage = global::GUI_Pizza.Properties.Resources.Homemade_Pizza_EXPS_HCA20_376_E07_09_2b;
            this.pnlPizza3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pnlPizza3.Location = new System.Drawing.Point(8, 352);
            this.pnlPizza3.Name = "pnlPizza3";
            this.pnlPizza3.Size = new System.Drawing.Size(100, 100);
            this.pnlPizza3.TabIndex = 6;
            // 
            // pnlPizza1
            // 
            this.pnlPizza1.BackgroundImage = global::GUI_Pizza.Properties.Resources.depositphotos_30103299_stock_photo_pepperoni_pizza1;
            this.pnlPizza1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pnlPizza1.Location = new System.Drawing.Point(8, 140);
            this.pnlPizza1.Name = "pnlPizza1";
            this.pnlPizza1.Size = new System.Drawing.Size(100, 100);
            this.pnlPizza1.TabIndex = 5;
            // 
            // pnlLogo2
            // 
            this.pnlLogo2.BackgroundImage = global::GUI_Pizza.Properties.Resources.unknown;
            this.pnlLogo2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pnlLogo2.Location = new System.Drawing.Point(163, 4);
            this.pnlLogo2.Name = "pnlLogo2";
            this.pnlLogo2.Size = new System.Drawing.Size(188, 128);
            this.pnlLogo2.TabIndex = 4;
            // 
            // pnlLogo
            // 
            this.pnlLogo.BackgroundImage = global::GUI_Pizza.Properties.Resources.unknown;
            this.pnlLogo.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pnlLogo.Location = new System.Drawing.Point(12, 152);
            this.pnlLogo.Name = "pnlLogo";
            this.pnlLogo.Size = new System.Drawing.Size(339, 242);
            this.pnlLogo.TabIndex = 1;
            this.pnlLogo.Paint += new System.Windows.Forms.PaintEventHandler(this.PnlLogo_Paint);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(363, 574);
            this.Controls.Add(this.pnlPage2);
            this.Controls.Add(this.btnLogin);
            this.Controls.Add(this.pnlLogo);
            this.Controls.Add(this.lblWelcome);
            this.Controls.Add(this.tbxLogin);
            this.Name = "Form1";
            this.Text = "Form1";
            this.pnlPage2.ResumeLayout(false);
            this.pnlPage2.PerformLayout();
            this.pnlPage3.ResumeLayout(false);
            this.pnlPage3.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblWelcome;
        private System.Windows.Forms.Panel pnlLogo;
        private System.Windows.Forms.Button btnLogin;
        private System.Windows.Forms.Panel pnlPage2;
        private System.Windows.Forms.Label lblStatus;
        private System.Windows.Forms.Label lblOrder;
        private System.Windows.Forms.Label lblCashier;
        private System.Windows.Forms.Panel pnlLogo2;
        private System.Windows.Forms.Panel pnlPizza1;
        private System.Windows.Forms.Button btnPizza1Remove;
        private System.Windows.Forms.Button btnPizza1Add;
        private System.Windows.Forms.CheckedListBox clbPizza3;
        private System.Windows.Forms.CheckedListBox clbPizza2;
        private System.Windows.Forms.CheckedListBox clbPizza1;
        private System.Windows.Forms.Panel pnlPizza2;
        private System.Windows.Forms.Panel pnlPizza3;
        private System.Windows.Forms.Button ReadyOrders;
        private System.Windows.Forms.Button btnNewOrder;
        private System.Windows.Forms.Button btnConfirmOrder;
        private System.Windows.Forms.Button btnPizza2Remove;
        private System.Windows.Forms.Button btnPizza2Add;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Label lblPizza3Count;
        private System.Windows.Forms.Button btnPizza3Add;
        private System.Windows.Forms.Panel pnlPage3;
        private System.Windows.Forms.Button btnReadyOrders2;
        private System.Windows.Forms.Button btnNewOrder2;
        private System.Windows.Forms.Label lblOrders;
        private System.Windows.Forms.Panel pnlLogo3;
        private System.Windows.Forms.Label lblCashier2;
        private System.Windows.Forms.TextBox tbxLogin;
        private System.Windows.Forms.ListBox lbxReadyOrders;
        private System.Windows.Forms.Timer tmrTick;
        private System.Windows.Forms.Button btnServe;
        private System.Windows.Forms.Label lblPizza2Count;
        private System.Windows.Forms.Label lblPizza1Count;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel2;
    }
}

