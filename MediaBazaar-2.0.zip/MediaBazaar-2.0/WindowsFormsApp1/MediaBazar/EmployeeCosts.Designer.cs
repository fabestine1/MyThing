﻿namespace MediaBazar
{
    partial class EmployeeCosts
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.nameLbl = new System.Windows.Forms.Label();
            this.mondayBttn = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.wednesdayBttn = new System.Windows.Forms.Button();
            this.fridayBttn = new System.Windows.Forms.Button();
            this.tuesdayBttn = new System.Windows.Forms.Button();
            this.thursdayBttn = new System.Windows.Forms.Button();
            this.saturdayBttn = new System.Windows.Forms.Button();
            this.sundayBttn = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.costsLbl = new System.Windows.Forms.Label();
            this.wageLbl = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // nameLbl
            // 
            this.nameLbl.AutoSize = true;
            this.nameLbl.Font = new System.Drawing.Font("Montserrat", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nameLbl.Location = new System.Drawing.Point(43, 17);
            this.nameLbl.Name = "nameLbl";
            this.nameLbl.Size = new System.Drawing.Size(130, 33);
            this.nameLbl.TabIndex = 110;
            this.nameLbl.Text = "First Last";
            // 
            // mondayBttn
            // 
            this.mondayBttn.BackColor = System.Drawing.Color.LightCoral;
            this.mondayBttn.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.mondayBttn.FlatAppearance.BorderSize = 0;
            this.mondayBttn.Font = new System.Drawing.Font("Montserrat", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mondayBttn.Location = new System.Drawing.Point(41, 104);
            this.mondayBttn.Name = "mondayBttn";
            this.mondayBttn.Size = new System.Drawing.Size(114, 36);
            this.mondayBttn.TabIndex = 111;
            this.mondayBttn.Text = "Monday";
            this.mondayBttn.UseVisualStyleBackColor = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Montserrat", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(44, 65);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(137, 27);
            this.label1.TabIndex = 112;
            this.label1.Text = "Available on:";
            // 
            // wednesdayBttn
            // 
            this.wednesdayBttn.BackColor = System.Drawing.Color.LightCoral;
            this.wednesdayBttn.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.wednesdayBttn.FlatAppearance.BorderSize = 0;
            this.wednesdayBttn.Font = new System.Drawing.Font("Montserrat", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.wednesdayBttn.ForeColor = System.Drawing.SystemColors.ControlText;
            this.wednesdayBttn.Location = new System.Drawing.Point(41, 146);
            this.wednesdayBttn.Name = "wednesdayBttn";
            this.wednesdayBttn.Size = new System.Drawing.Size(114, 36);
            this.wednesdayBttn.TabIndex = 113;
            this.wednesdayBttn.Text = "Wednesday";
            this.wednesdayBttn.UseVisualStyleBackColor = false;
            // 
            // fridayBttn
            // 
            this.fridayBttn.BackColor = System.Drawing.Color.LightCoral;
            this.fridayBttn.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.fridayBttn.FlatAppearance.BorderSize = 0;
            this.fridayBttn.Font = new System.Drawing.Font("Montserrat", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.fridayBttn.Location = new System.Drawing.Point(41, 188);
            this.fridayBttn.Name = "fridayBttn";
            this.fridayBttn.Size = new System.Drawing.Size(114, 36);
            this.fridayBttn.TabIndex = 114;
            this.fridayBttn.Text = "Friday";
            this.fridayBttn.UseVisualStyleBackColor = false;
            // 
            // tuesdayBttn
            // 
            this.tuesdayBttn.BackColor = System.Drawing.Color.LightCoral;
            this.tuesdayBttn.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.tuesdayBttn.FlatAppearance.BorderSize = 0;
            this.tuesdayBttn.Font = new System.Drawing.Font("Montserrat", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tuesdayBttn.Location = new System.Drawing.Point(161, 104);
            this.tuesdayBttn.Name = "tuesdayBttn";
            this.tuesdayBttn.Size = new System.Drawing.Size(126, 36);
            this.tuesdayBttn.TabIndex = 115;
            this.tuesdayBttn.Text = "Tuesday";
            this.tuesdayBttn.UseVisualStyleBackColor = false;
            // 
            // thursdayBttn
            // 
            this.thursdayBttn.BackColor = System.Drawing.Color.LightCoral;
            this.thursdayBttn.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.thursdayBttn.FlatAppearance.BorderSize = 0;
            this.thursdayBttn.Font = new System.Drawing.Font("Montserrat", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.thursdayBttn.Location = new System.Drawing.Point(161, 146);
            this.thursdayBttn.Name = "thursdayBttn";
            this.thursdayBttn.Size = new System.Drawing.Size(126, 36);
            this.thursdayBttn.TabIndex = 116;
            this.thursdayBttn.Text = "Thursday";
            this.thursdayBttn.UseVisualStyleBackColor = false;
            // 
            // saturdayBttn
            // 
            this.saturdayBttn.BackColor = System.Drawing.Color.LightCoral;
            this.saturdayBttn.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.saturdayBttn.FlatAppearance.BorderSize = 0;
            this.saturdayBttn.Font = new System.Drawing.Font("Montserrat", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.saturdayBttn.Location = new System.Drawing.Point(161, 188);
            this.saturdayBttn.Name = "saturdayBttn";
            this.saturdayBttn.Size = new System.Drawing.Size(126, 36);
            this.saturdayBttn.TabIndex = 117;
            this.saturdayBttn.Text = "Saturday";
            this.saturdayBttn.UseVisualStyleBackColor = false;
            // 
            // sundayBttn
            // 
            this.sundayBttn.BackColor = System.Drawing.Color.LightCoral;
            this.sundayBttn.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.sundayBttn.FlatAppearance.BorderSize = 0;
            this.sundayBttn.Font = new System.Drawing.Font("Montserrat", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.sundayBttn.Location = new System.Drawing.Point(95, 230);
            this.sundayBttn.Name = "sundayBttn";
            this.sundayBttn.Size = new System.Drawing.Size(105, 36);
            this.sundayBttn.TabIndex = 118;
            this.sundayBttn.Text = "Sunday";
            this.sundayBttn.UseVisualStyleBackColor = false;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Montserrat", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(45, 286);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(130, 27);
            this.label2.TabIndex = 119;
            this.label2.Text = "Wage/hour:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Montserrat", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(45, 323);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(121, 27);
            this.label3.TabIndex = 120;
            this.label3.Text = "Total costs:";
            // 
            // costsLbl
            // 
            this.costsLbl.AutoSize = true;
            this.costsLbl.Font = new System.Drawing.Font("Montserrat", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.costsLbl.Location = new System.Drawing.Point(229, 323);
            this.costsLbl.Name = "costsLbl";
            this.costsLbl.Size = new System.Drawing.Size(37, 27);
            this.costsLbl.TabIndex = 121;
            this.costsLbl.Text = "0$";
            // 
            // wageLbl
            // 
            this.wageLbl.AutoSize = true;
            this.wageLbl.Font = new System.Drawing.Font("Montserrat", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.wageLbl.Location = new System.Drawing.Point(229, 286);
            this.wageLbl.Name = "wageLbl";
            this.wageLbl.Size = new System.Drawing.Size(37, 27);
            this.wageLbl.TabIndex = 122;
            this.wageLbl.Text = "0$";
            // 
            // EmployeeCosts
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Info;
            this.Controls.Add(this.wageLbl);
            this.Controls.Add(this.costsLbl);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.sundayBttn);
            this.Controls.Add(this.saturdayBttn);
            this.Controls.Add(this.thursdayBttn);
            this.Controls.Add(this.tuesdayBttn);
            this.Controls.Add(this.fridayBttn);
            this.Controls.Add(this.wednesdayBttn);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.mondayBttn);
            this.Controls.Add(this.nameLbl);
            this.Name = "EmployeeCosts";
            this.Size = new System.Drawing.Size(321, 386);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label nameLbl;
        private System.Windows.Forms.Button mondayBttn;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button wednesdayBttn;
        private System.Windows.Forms.Button fridayBttn;
        private System.Windows.Forms.Button tuesdayBttn;
        private System.Windows.Forms.Button thursdayBttn;
        private System.Windows.Forms.Button saturdayBttn;
        private System.Windows.Forms.Button sundayBttn;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label costsLbl;
        private System.Windows.Forms.Label wageLbl;
    }
}
