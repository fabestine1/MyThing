﻿namespace MediaBazar
{
    public enum ProfileRoles
    {
        ADMINISTRATOR,
        MANAGER,
        EMPLOYEE
    }
}
