﻿namespace MediaBazar
{
    public class Announcement
    {
    }
}