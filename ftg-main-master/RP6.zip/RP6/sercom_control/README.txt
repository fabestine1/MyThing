ZET deze map in:
rp6/RP6Examples_20120725f/assignments.control_board/

NOTE: sercom_control bestaat al!